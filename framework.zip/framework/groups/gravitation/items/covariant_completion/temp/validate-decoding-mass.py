"""Covariant Completion mass decoding validation suite.

Validates the inverse mass decoding pipeline defined by
M_dec(r) = r*v^4 / [G*(a0*r + v^2)] using SPARC style galaxy data.
The suite targets referee relevant properties of invertibility, stability,
data scaling, and baryonic consistency without dark matter halo fitting.
"""

import json
import math
import os

import numpy as np


G_SI = 6.67430e-11
A0_SI = 1.2e-10
M_SUN = 1.989e30
KPC_M = 3.0857e19


def _sparc_dir():
    here = os.path.dirname(os.path.abspath(__file__))
    docs_root = os.path.abspath(os.path.join(here, "..", "..", "..", "..", "..", ".."))
    repo_root = os.path.abspath(os.path.join(docs_root, ".."))
    candidates = [
        os.path.join(docs_root, "sparc"),
        os.path.join(repo_root, "docs", "sparc"),
        os.path.join(repo_root, "gravis", "sparc"),
    ]
    for path in candidates:
        if os.path.isdir(path):
            return path
    raise FileNotFoundError("Could not locate SPARC directory")


def _load_json(path):
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def load_galaxy(gal_id):
    base = _sparc_dir()
    path = os.path.join(base, gal_id + ".json")
    if not os.path.isfile(path):
        raise FileNotFoundError("Missing galaxy file: %s" % gal_id)
    return _load_json(path)


def load_catalog_ids():
    base = _sparc_dir()
    catalog_path = os.path.join(base, "catalog.json")
    catalog = _load_json(catalog_path)
    return [entry["id"] for entry in catalog if "id" in entry]


def decode_mass_msun(r_kpc, v_kms, g=G_SI, a0=A0_SI):
    r = r_kpc * KPC_M
    v = v_kms * 1e3
    return (r * v**4) / (g * (a0 * r + v**2)) / M_SUN


def decode_mass_via_transition_msun(r_kpc, v_kms, g=G_SI, a0=A0_SI):
    r = r_kpc * KPC_M
    v = v_kms * 1e3
    g_t = v**2 / r
    g_s = g_t**2 / (a0 + g_t)
    return g_s * r**2 / g / M_SUN


def forward_velocity_from_mass_kms(r_kpc, mass_msun, g=G_SI, a0=A0_SI):
    r = r_kpc * KPC_M
    g_s = g * (mass_msun * M_SUN) / r**2
    g_t = 0.5 * (g_s + math.sqrt(g_s**2 + 4.0 * g_s * a0))
    return math.sqrt(g_t * r) / 1e3


def newtonian_dynamic_mass_msun(r_kpc, v_kms, g=G_SI):
    r = r_kpc * KPC_M
    v = v_kms * 1e3
    return (r * v**2) / g / M_SUN


def enclosed_baryonic_mass_msun(r_kpc, mass_model):
    bulge = mass_model["bulge"]["M"] * r_kpc**2 / (r_kpc + mass_model["bulge"]["a"])**2
    xd = r_kpc / mass_model["disk"]["Rd"]
    disk = mass_model["disk"]["M"] * (1.0 - (1.0 + xd) * math.exp(-xd))
    xg = r_kpc / mass_model["gas"]["Rd"]
    gas = mass_model["gas"]["M"] * (1.0 - (1.0 + xg) * math.exp(-xg))
    return bulge + disk + gas


def total_baryonic_mass_msun(mass_model):
    return mass_model["bulge"]["M"] + mass_model["disk"]["M"] + mass_model["gas"]["M"]


def nfw_mass_msun(r_kpc, rho0, rs_kpc):
    r = r_kpc * KPC_M
    rs = rs_kpc * KPC_M
    x = r / rs
    m = 4.0 * math.pi * rho0 * rs**3 * (math.log(1.0 + x) - x / (1.0 + x))
    return m / M_SUN


def key_ids():
    return ["milky_way", "m33", "ngc3198", "camb"]


def print_summary(why, what, pass_if):
    """Print concise context for test output."""
    print("why: %s" % why)
    print("what: %s" % what)
    print("pass_if: %s" % pass_if)


def print_metric(name, value, meaning):
    """Print labeled metric output."""
    print("result: %s=%s (%s)" % (name, value, meaning))


# Scientific reasoning: decoding formula must match the transition based derivation exactly.
def check_decoding_formula_equivalence():
    """Closed form and transition based decoded mass are numerically identical."""
    print_summary(
        "The mass decode equation is central to the paper claim.",
        "Maximum relative difference between closed form and transition derivation.",
        "Relative difference remains below 1e-12 for all sampled points.",
    )
    radii = [0.3, 1.0, 5.0, 20.0, 50.0]
    vels = [10.0, 30.0, 80.0, 150.0, 230.0]
    max_rel = 0.0
    for r in radii:
        for v in vels:
            m1 = decode_mass_msun(r, v)
            m2 = decode_mass_via_transition_msun(r, v)
            rel = abs(m1 - m2) / max(abs(m1), 1e-30)
            max_rel = max(max_rel, rel)
            assert rel < 1e-12, "Formula mismatch at r=%g v=%g: rel=%g" % (r, v, rel)
    print_metric("decoding_formula_max_relative_error", max_rel, "Numerical identity check")


# Scientific reasoning: decoded mass to velocity round trip validates algebraic invertibility.
def check_round_trip_velocity_consistency():
    """Velocity reconstructed from decoded mass recovers observed velocity."""
    print_summary(
        "Invertibility is required for a decode and re encode pipeline.",
        "Maximum absolute velocity mismatch after round trip.",
        "Absolute mismatch remains below 1e-9 km/s.",
    )
    max_abs = 0.0
    for gid in key_ids():
        gal = load_galaxy(gid)
        for obs in gal["observations"]:
            r = float(obs["r"])
            v = float(obs["v"])
            m_dec = decode_mass_msun(r, v)
            v_rec = forward_velocity_from_mass_kms(r, m_dec)
            err = abs(v_rec - v)
            max_abs = max(max_abs, err)
            assert err < 1e-9, "Round trip mismatch for %s at r=%g: %g" % (gid, r, err)
    print_metric("round_trip_velocity_max_abs_error_kms", max_abs, "Round trip closure")


# Scientific reasoning: physical decoded mass must remain positive and finite for all measurements.
def check_decoded_mass_positive_finite_key_galaxies():
    """Decoded masses are finite and positive on key galaxy curves."""
    print_summary(
        "A physical decoded mass must be finite and positive.",
        "Number of key data points checked for positivity and finiteness.",
        "All checked points pass positivity and finiteness.",
    )
    total_points = 0
    for gid in key_ids():
        gal = load_galaxy(gid)
        for obs in gal["observations"]:
            m_dec = decode_mass_msun(float(obs["r"]), float(obs["v"]))
            total_points += 1
            assert math.isfinite(m_dec), "Nonfinite decoded mass for %s" % gid
            assert m_dec > 0.0, "Nonpositive decoded mass for %s" % gid
    print_metric("decoded_mass_points_checked", total_points, "Coverage count")


# Scientific reasoning: broad catalog coverage verifies decoding stability across morphology diversity.
def check_catalog_decoding_finite_sample():
    """Decoded mass remains finite and positive across the full SPARC catalog."""
    print_summary(
        "Catalog level stability matters more than a few hand picked examples.",
        "Number of sampled catalog points that decode cleanly.",
        "More than 300 sampled points pass positivity and finiteness.",
    )
    checked = 0
    for gid in load_catalog_ids():
        try:
            gal = load_galaxy(gid)
        except FileNotFoundError:
            continue
        obs = gal.get("observations", [])
        if len(obs) == 0:
            continue
        for point in (obs[0], obs[len(obs) // 2], obs[-1]):
            m_dec = decode_mass_msun(float(point["r"]), float(point["v"]))
            checked += 1
            assert math.isfinite(m_dec), "Nonfinite decoded mass for %s" % gid
            assert m_dec > 0.0, "Nonpositive decoded mass for %s" % gid
    assert checked > 300, "Catalog sample too small: %d" % checked
    print_metric("catalog_decoding_points_checked", checked, "Catalog sample size")


# Scientific reasoning: decoded mass must be below Newtonian dynamic mass since g_s < g_t in this framework.
def check_decoded_below_newtonian_dynamic_mass():
    """Decoded mass is strictly below Newtonian dynamic mass for all key points."""
    print_summary(
        "This framework implies g_s is below g_t, so decoded mass is below Newtonian dynamic mass.",
        "Range of decoded to Newtonian mass ratio across key data points.",
        "All ratios remain below 1.0.",
    )
    min_ratio = 1.0
    max_ratio = 0.0
    for gid in key_ids():
        gal = load_galaxy(gid)
        for obs in gal["observations"]:
            r = float(obs["r"])
            v = float(obs["v"])
            m_dec = decode_mass_msun(r, v)
            m_newt = newtonian_dynamic_mass_msun(r, v)
            ratio = m_dec / max(m_newt, 1e-30)
            min_ratio = min(min_ratio, ratio)
            max_ratio = max(max_ratio, ratio)
            assert ratio < 1.0, "Decoded mass not below Newtonian for %s" % gid
    print_metric("decoded_to_newtonian_ratio_min", min_ratio, "Lower bound of ratio range")
    print_metric("decoded_to_newtonian_ratio_max", max_ratio, "Upper bound of ratio range")


# Scientific reasoning: reported key galaxies should decode near baryonic scale without halo fitting.
def check_outer_mass_ratio_mw_m33_ngc3198():
    """Outer decoded to total baryonic ratios stay in referee useful range for key systems."""
    print_summary(
        "These three systems are used in the letter as near baryonic benchmark cases, not as a universal rule for every galaxy.",
        "Outer radius decoded to total baryonic mass ratio for Milky Way, M33, and NGC3198.",
        "Each benchmark ratio remains in its declared near baryonic evidence band, while active deficit systems are tested separately.",
    )
    bounds = {
        "milky_way": (0.5, 1.5),
        "m33": (1.0, 2.5),
        "ngc3198": (0.5, 1.2),
    }
    for gid, (lo, hi) in bounds.items():
        gal = load_galaxy(gid)
        obs = gal["observations"][-1]
        ratio = decode_mass_msun(obs["r"], obs["v"]) / total_baryonic_mass_msun(gal["mass_model"])
        print_metric(
            "%s_outer_decoded_to_baryonic_ratio" % gid,
            ratio,
            "How close decoded mass is to observed baryonic scale at outer radius",
        )
        assert lo <= ratio <= hi, (
            "%s ratio %g outside [%g,%g]" % (gid, ratio, lo, hi)
        )


# Scientific reasoning: interior topology state maps to opposite signs between velocity residual and mass deficit by construction.
def check_topology_state_sign_consistency():
    """Sign of velocity residual against photometric baseline is opposite to sign of mass deficit."""
    print_summary(
        "In the vortex picture, absorbing versus pumping state is identified by observed velocity against photometric baseline, and the decoded deficit sign is complementary by definition.",
        "Per radius sign consistency between delta_v = v_obs - v_phot and delta_M = M_bar - M_dec.",
        "Opposite sign consistency fraction exceeds 0.95 for each key galaxy.",
    )
    for gid in key_ids():
        gal = load_galaxy(gid)
        model = gal["mass_model"]
        rs = np.array([obs["r"] for obs in gal["observations"]], dtype=float)
        v_obs = np.array([obs["v"] for obs in gal["observations"]], dtype=float)
        m_bar = np.array([enclosed_baryonic_mass_msun(r, model) for r in rs], dtype=float)

        g_s_phot = G_SI * (m_bar * M_SUN) / (rs * KPC_M) ** 2
        g_t_phot = 0.5 * (g_s_phot + np.sqrt(g_s_phot**2 + 4.0 * g_s_phot * A0_SI))
        v_phot = np.sqrt(g_t_phot * rs * KPC_M) / 1e3

        m_dec = np.array([decode_mass_msun(r, v) for r, v in zip(rs, v_obs)], dtype=float)
        delta_v = v_obs - v_phot
        delta_m = m_bar - m_dec

        signs_match = np.sign(delta_v) == -np.sign(delta_m)
        strong = (np.abs(delta_v) > 1e-9) | (np.abs(delta_m) > 1e-6)
        if np.any(strong):
            frac = float(np.mean(signs_match[strong]))
        else:
            frac = 1.0
        print_metric("%s_state_sign_consistency_fraction" % gid, frac, "Absorbing or pumping sign complementarity")
        assert frac > 0.95, "Weak sign consistency for %s" % gid


# Scientific reasoning: low surface brightness deficit signature should appear where interior contribution dominates.
def check_camb_deficit_signature():
    """CamB outer decoded mass remains below outer baryonic total."""
    print_summary(
        "CamB is used as a deficit style example in the manuscript discussion.",
        "Outer decoded to total baryonic mass ratio for CamB.",
        "Ratio remains below 0.5 for a clear deficit signature.",
    )
    gal = load_galaxy("camb")
    obs = gal["observations"][-1]
    ratio = decode_mass_msun(obs["r"], obs["v"]) / total_baryonic_mass_msun(gal["mass_model"])
    print_metric("camb_outer_decoded_to_baryonic_ratio", ratio, "Deficit indicator")
    assert ratio < 0.5, "CamB deficit signature not present"


# Scientific reasoning: velocity uncertainty should propagate monotonically into decoded mass.
def check_velocity_error_monotonicity():
    """Decoded mass increases monotonically with velocity perturbation at fixed radius."""
    print_summary(
        "Decoded mass must respond predictably to observational velocity uncertainty.",
        "Minimum decoded mass increase when velocity is perturbed upward by one error bar.",
        "All points show strictly monotonic increase with higher velocity.",
    )
    min_gain = 1e99
    for gid in key_ids():
        gal = load_galaxy(gid)
        for obs in gal["observations"]:
            r = float(obs["r"])
            v = float(obs["v"])
            dv = max(float(obs.get("err", 1.0)), 0.5)
            m_lo = decode_mass_msun(r, max(v - dv, 0.1))
            m_mid = decode_mass_msun(r, v)
            m_hi = decode_mass_msun(r, v + dv)
            assert m_lo < m_mid < m_hi, "Nonmonotonic decode for %s at r=%g" % (gid, r)
            min_gain = min(min_gain, m_hi - m_mid)
    print_metric("min_decoded_mass_gain_from_plus_sigma", min_gain, "Sensitivity floor")


# Scientific reasoning: decoding must not depend on baryonic model assumptions, only observed kinematics.
def check_decoding_independent_of_mass_model():
    """Decoded masses are invariant under baryonic model perturbation."""
    print_summary(
        "Decoding should use kinematics only, not an assumed baryonic model.",
        "Maximum relative decoded mass change after large baryonic model scaling.",
        "Relative change remains near machine precision.",
    )
    gid = "milky_way"
    gal = load_galaxy(gid)
    model = gal["mass_model"]
    ratios = [0.1, 1.0, 10.0]
    base = [decode_mass_msun(obs["r"], obs["v"]) for obs in gal["observations"]]
    for scale in ratios:
        model["disk"]["M"] *= scale
        model["gas"]["M"] *= scale
        test = [decode_mass_msun(obs["r"], obs["v"]) for obs in gal["observations"]]
        max_rel = np.max(np.abs((np.array(test) - np.array(base)) / np.maximum(base, 1e-30)))
        print_metric(
            "mass_model_scale_%g_max_relative_change" % scale,
            max_rel,
            "Decoding independence under model scaling",
        )
        assert max_rel < 1e-15, "Decoding changed under mass model perturbation"


# Scientific reasoning: decoded and enclosed baryonic masses should remain same order for benchmark galaxies.
def check_decoded_vs_baryonic_median_ratio_by_galaxy():
    """Median decoded to enclosed baryonic ratio stays bounded on benchmark galaxies."""
    print_summary(
        "Within galaxy consistency matters more than pointwise noise at single radii.",
        "Median and upper quantile of decoded to enclosed baryonic mass ratio.",
        "Median remains between 0.5 and 2.5 and q95 remains below 3.0.",
    )
    for gid in ["milky_way", "m33", "ngc3198"]:
        gal = load_galaxy(gid)
        ratios = []
        for obs in gal["observations"]:
            r = float(obs["r"])
            m_dec = decode_mass_msun(r, float(obs["v"]))
            m_bar = enclosed_baryonic_mass_msun(r, gal["mass_model"])
            ratios.append(m_dec / max(m_bar, 1e-30))
        ratios = np.array(ratios, dtype=float)
        med = float(np.median(ratios))
        q95 = float(np.quantile(ratios, 0.95))
        print_metric("%s_median_decoded_to_enclosed_ratio" % gid, med, "Central tendency")
        print_metric("%s_q95_decoded_to_enclosed_ratio" % gid, q95, "Upper tail control")
        assert 0.5 <= med <= 2.5, "Median ratio out of range for %s" % gid
        assert q95 < 3.0, "Upper tail ratio too large for %s" % gid


# Scientific reasoning: catalog level decoded to baryonic ratios should concentrate near order unity.
def check_catalog_ratio_distribution():
    """Catalog ratio distribution stays in broad physically interpretable bounds."""
    print_summary(
        "A referee expects broad catalog behavior, not only hand selected cases.",
        "Catalog quantiles of outer decoded to total baryonic ratio.",
        "Quantiles and in band fraction remain within declared broad bounds.",
    )
    ratios = []
    for gid in load_catalog_ids():
        try:
            gal = load_galaxy(gid)
        except FileNotFoundError:
            continue
        obs = gal.get("observations", [])
        mm = gal.get("mass_model", {})
        if len(obs) == 0:
            continue
        if not all(k in mm for k in ["bulge", "disk", "gas"]):
            continue
        total = total_baryonic_mass_msun(mm)
        if total <= 0:
            continue
        last = obs[-1]
        ratios.append(decode_mass_msun(last["r"], last["v"]) / total)
    ratios = np.array(ratios, dtype=float)
    q05 = float(np.quantile(ratios, 0.05))
    med = float(np.median(ratios))
    q95 = float(np.quantile(ratios, 0.95))
    frac = float(np.mean((ratios >= 0.1) & (ratios <= 10.0)))
    print_metric("catalog_ratio_q05", q05, "Lower tail")
    print_metric("catalog_ratio_median", med, "Central tendency")
    print_metric("catalog_ratio_q95", q95, "Upper tail")
    print_metric("catalog_ratio_fraction_0p1_to_10", frac, "Broad bounded fraction")
    assert len(ratios) >= 150, "Catalog coverage too low"
    assert q05 > 0.1, "Lower tail too small"
    assert 0.5 < med < 1.5, "Median ratio not near order unity"
    assert q95 < 3.0, "Upper tail too large"
    assert frac > 0.95, "Too few galaxies in broad ratio band"


# Scientific reasoning: letter claimed LCDM gap significance should persist at outer reference points.
def check_sigma_gap_vs_lcdm_reference_points():
    """Reference point decoded masses remain many sigma below LCDM enclosed mass."""
    print_summary(
        "The letter quotes significance gaps versus LCDM at reference radii.",
        "Sigma level difference between LCDM enclosed mass and decoded mass.",
        "MW remains above 5 sigma and M33 remains above 10 sigma.",
    )
    mw = load_galaxy("milky_way")
    mw_r = 50.0
    mw_v = 180.0
    mw_err = 32.0
    mw_dec = decode_mass_msun(mw_r, mw_v)
    mw_dec_hi = decode_mass_msun(mw_r, mw_v + mw_err)
    mw_sigma_mass = max(mw_dec_hi - mw_dec, 1e-30)
    mw_lcdm = enclosed_baryonic_mass_msun(mw_r, mw["mass_model"]) + nfw_mass_msun(
        mw_r, rho0=1.826e-21, rs_kpc=9.3
    )
    sigma_mw = (mw_lcdm - mw_dec) / mw_sigma_mass

    m33 = load_galaxy("m33")
    m33_r = 17.0
    m33_v = 130.0
    m33_err = 8.0
    m33_dec = decode_mass_msun(m33_r, m33_v)
    m33_dec_hi = decode_mass_msun(m33_r, m33_v + m33_err)
    m33_sigma_mass = max(m33_dec_hi - m33_dec, 1e-30)
    m33_lcdm = enclosed_baryonic_mass_msun(m33_r, m33["mass_model"]) + nfw_mass_msun(
        m33_r, rho0=2.924e-23, rs_kpc=101.5
    )
    sigma_m33 = (m33_lcdm - m33_dec) / m33_sigma_mass

    print_metric("sigma_gap_mw", sigma_mw, "MW significance at 50 kpc")
    print_metric("sigma_gap_m33", sigma_m33, "M33 significance at 17 kpc")
    assert sigma_mw > 5.0, "MW sigma gap too small"
    assert sigma_m33 > 10.0, "M33 sigma gap too small"


# Scientific reasoning: effective mass deficit should be sign varying across systems, matching topology driven interpretation.
def check_deficit_sign_diversity():
    """Decoded minus baryonic outer mass shows both positive and negative cases across key galaxies."""
    print_summary(
        "The manuscript frames both excess and deficit style systems.",
        "Signs of outer decoded minus baryonic mass across benchmark galaxies.",
        "At least one positive and one negative case are present.",
    )
    diffs = []
    for gid in key_ids():
        gal = load_galaxy(gid)
        last = gal["observations"][-1]
        dec = decode_mass_msun(last["r"], last["v"])
        bar = total_baryonic_mass_msun(gal["mass_model"])
        diffs.append(dec - bar)
    pos = any(d > 0 for d in diffs)
    neg = any(d < 0 for d in diffs)
    print_metric("outer_mass_deficit_signs", diffs, "Signed differences in solar masses")
    assert pos and neg, "Need both positive and negative deficit cases"


if __name__ == "__main__":
    import inspect
    import sys
    import time

    checks = sorted(
        (name, fn)
        for name, fn in inspect.getmembers(sys.modules[__name__], inspect.isfunction)
        if name.startswith("check_")
    )

    passed = 0
    failed = 0
    for name, fn in checks:
        t0 = time.perf_counter()
        try:
            fn()
            dt = (time.perf_counter() - t0) * 1000
            print("  PASS  %-50s  (%.2fms)" % (name, dt))
            passed += 1
        except AssertionError as e:
            dt = (time.perf_counter() - t0) * 1000
            print("  FAIL  %-50s  (%.2fms)  %s" % (name, dt, e))
            failed += 1
        except Exception as e:
            dt = (time.perf_counter() - t0) * 1000
            print("  ERROR %-50s  (%.2fms)  %s" % (name, dt, e))
            failed += 1

    print()
    print("%d passed, %d failed, %d total" % (passed, failed, passed + failed))
    sys.exit(1 if failed else 0)
